-- Crea la base de dades si no existeix
DROP DATABASE IF EXISTS institut;
CREATE DATABASE IF NOT EXISTS institut;
USE institut;